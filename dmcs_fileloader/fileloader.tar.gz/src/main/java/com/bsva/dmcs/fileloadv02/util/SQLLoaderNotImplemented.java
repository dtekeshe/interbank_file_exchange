package com.bsva.dmcs.fileloadv02.util;

/**
 * TODO Document
 */
public class SQLLoaderNotImplemented extends Exception {
    public SQLLoaderNotImplemented(String message) {
        super(message);
    }
}
