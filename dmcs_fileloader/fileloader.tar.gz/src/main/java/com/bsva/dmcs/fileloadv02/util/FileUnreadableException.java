package com.bsva.dmcs.fileloadv02.util;

/**
 * TODO Document
 */
public class FileUnreadableException extends Exception {
    public FileUnreadableException(String message) {
        super(message);
    }
}
