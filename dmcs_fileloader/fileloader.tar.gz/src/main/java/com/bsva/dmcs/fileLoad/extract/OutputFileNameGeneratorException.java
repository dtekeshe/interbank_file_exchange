//package com.bsva.dmcs.fileLoad.extract;
//
//public class OutputFileNameGeneratorException extends Exception {
//
//
//	public OutputFileNameGeneratorException(){
//		super();
//	}
//
//	public OutputFileNameGeneratorException(String msg){
//		super(msg);
//	}
//
//	public OutputFileNameGeneratorException(String msg, Throwable cause){
//		super(msg, cause);
//	}
//}
