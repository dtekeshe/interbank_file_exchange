package com.bsva.dmcs.fileloadv02.dto;

/**
 *
 */
public enum DirectoryName {
    INPUT, RECEIVE, SEND, PREV, REPORTS, APPS, SPOLOG, TMP
}
