//package com.bsva.dmcs.fileLoad;
//
//import com.bsva.dmcs.fileLoad.masterCard.MasterCardFileSaver;
//import com.bsva.dmcs.fileLoad.visa.VisaFileSaver;
//
//public class SaveFactory {
//
//	public static Saver getFileSaver(String subService){
//
//		if (subService.equalsIgnoreCase("MASTERCARD"))
//			return new MasterCardFileSaver();
//		else
//			return new VisaFileSaver();
//	}
//
//}
