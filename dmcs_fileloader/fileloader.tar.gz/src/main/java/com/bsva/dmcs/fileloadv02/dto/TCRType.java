package com.bsva.dmcs.fileloadv02.dto;

/**
 * TODO Document
 */
public enum TCRType {
    HEADER,
    SECONDARY_HEADER,
    FINANCIAL,
    NON_FINANCIAL,
    INVALID_TXN,
    END_OF_FILE,
    TRAILER,
    INVALID_REC
}
