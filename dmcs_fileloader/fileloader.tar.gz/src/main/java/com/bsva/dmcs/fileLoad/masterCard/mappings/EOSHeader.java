//
//package com.bsva.dmcs.fileLoad.masterCard.mappings;
//
///**
// *
// * @author SimphiweT
// */
//public class EOSHeader {
//
//    private String recordEntry;
//
//    public String getRecordEntry() {
//        return recordEntry;
//    }
//
//    public void setRecordEntry(String recordEntry) {
//        this.recordEntry = recordEntry;
//    }
//
//    @Override
//    public String toString() {
//
//        StringBuilder builder = new StringBuilder();
//
//        builder.append(getRecordEntry());
//        return builder.toString();
//    }
//
//
//}
