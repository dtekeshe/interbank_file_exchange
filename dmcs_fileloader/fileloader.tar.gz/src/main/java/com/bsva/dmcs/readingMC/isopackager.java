//package com.bsva.dmcs.readingMC;
//
//import java.util.ArrayList;
//
//import javax.xml.bind.annotation.XmlElement;
//import javax.xml.bind.annotation.XmlRootElement;
//
//@XmlRootElement
//public class isopackager {
//
//	private ArrayList<isofield> isoFieldList;
//
//	public ArrayList<isofield> getIsoFieldList() {
//		return isoFieldList;
//	}
//
//	@XmlElement(name = "isofield")
//	public void setIsoFieldList(ArrayList<isofield> isoFieldList) {
//		this.isoFieldList = isoFieldList;
//	}
//
//}
