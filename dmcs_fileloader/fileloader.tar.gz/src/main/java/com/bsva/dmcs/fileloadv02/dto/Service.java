package com.bsva.dmcs.fileloadv02.dto;

public enum Service {
    CARD;
}
