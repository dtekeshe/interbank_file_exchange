//package com.bsva.dmcs.fileLoad;
//
//
//import java.sql.Connection;
//
//import com.bsva.dcms.commons.dto.file.FileDTO;
//import com.bsva.dmcs.fileLoad.exceptions.FileLoadException;
//
//public interface Loader {
//
//	public FileDTO load(String fileName) throws FileLoadException;
//	public void setConnection(Connection connection);
//}
