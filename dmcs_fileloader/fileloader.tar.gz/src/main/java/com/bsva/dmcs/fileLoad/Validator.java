//package com.bsva.dmcs.fileLoad;
//
//import javax.sql.DataSource;
//
//import com.bsva.dcms.commons.dto.file.FileDTO;
//import com.bsva.dmcs.fileLoad.exceptions.FileLoadException;
//
//
//public interface Validator {
//
//	public void validate(FileDTO fileDto) throws FileLoadException;
//	public void setConnection(DataSource conn);
//}
