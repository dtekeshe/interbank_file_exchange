//package com.bsva.dmcs.fileLoad.exceptions;
//
//public class FileLoadException extends Exception {
//
//
//	public FileLoadException(){
//		super();
//	}
//
//	public FileLoadException(String msg){
//		super(msg);
//	}
//
//	public FileLoadException(String msg, Throwable cause){
//		super(msg, cause);
//	}
//}
