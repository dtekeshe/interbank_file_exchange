//
//package com.bsva.dmcs.fileLoad.masterCard.mappings;
//
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Map;
//
///**
// *
// * @author SimphiweT
// */
//public class PDSObject {
//
//    public PDSObject() {
//    }
//
//    private List<Map> pdsMapList = new ArrayList<>();
//
//    public List<Map> getPdsMapList() {
//        return pdsMapList;
//    }
//
//    public void setPdsMapList(List<Map> pdsMapList) {
//        this.pdsMapList = pdsMapList;
//    }
//
//
//
//}
