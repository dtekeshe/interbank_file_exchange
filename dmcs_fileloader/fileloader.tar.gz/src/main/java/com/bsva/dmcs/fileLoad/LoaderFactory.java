//package com.bsva.dmcs.fileLoad;
//
//import com.bsva.dmcs.fileLoad.masterCard.MasterCardFileLoader;
//import com.bsva.dmcs.fileLoad.visa.VisaFileLoader;
//
//public class LoaderFactory {
//
//	public static Loader getLoader(String subService){
//
//		if (subService.equalsIgnoreCase("MASTERCARD"))
//			return new MasterCardFileLoader();
//		else
//			return new VisaFileLoader();
//	}
//
//}
