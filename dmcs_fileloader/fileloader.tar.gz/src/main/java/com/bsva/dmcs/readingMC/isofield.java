//package com.bsva.dmcs.readingMC;
//
//import javax.xml.bind.annotation.XmlAttribute;
//import javax.xml.bind.annotation.XmlRootElement;
//
//@XmlRootElement(namespace = "com.bsva.dmcs.readingMC.isopackager")
//public class isofield {
//
//	private String id;
//	private String length;
//	private String name;
//	private String class_;
//	private String token;
//	private String pad;
//	public String getId() {
//		return id;
//	}
//
//	@XmlAttribute
//	public void setId(String id) {
//		this.id = id;
//	}
//	public String getLength() {
//		return length;
//	}
//
//	@XmlAttribute
//	public void setLength(String length) {
//		this.length = length;
//	}
//	public String getName() {
//		return name;
//	}
//
//	@XmlAttribute
//	public void setName(String name) {
//		this.name = name;
//	}
//
//	public String getToken() {
//		return token;
//	}
//
//	@XmlAttribute
//	public void setToken(String token) {
//		this.token = token;
//	}
//	public String getPad() {
//		return pad;
//	}
//
//	@XmlAttribute
//	public void setPad(String pad) {
//		this.pad = pad;
//	}
//	public String getClass_() {
//		return class_;
//	}
//
//	@XmlAttribute
//	public void setClass_(String class_) {
//		this.class_ = class_;
//	}
//
//}
