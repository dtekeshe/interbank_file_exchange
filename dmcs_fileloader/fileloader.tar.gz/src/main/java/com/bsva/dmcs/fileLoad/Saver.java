//package com.bsva.dmcs.fileLoad;
//
//
//import javax.sql.DataSource;
//
//import com.bsva.dcms.commons.dto.file.FileDTO;
//import com.bsva.dmcs.fileLoad.exceptions.FileLoadException;
//
//public interface Saver {
//
//	public void save(FileDTO fileDto) throws FileLoadException;
//	public void setConnection(DataSource conn);
//}
