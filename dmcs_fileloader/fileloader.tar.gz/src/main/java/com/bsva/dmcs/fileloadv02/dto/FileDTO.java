package com.bsva.dmcs.fileloadv02.dto;

/**
 * TODO documentation
 */
public class FileDTO {
    private final String filename;

    public FileDTO(String filename) {
        this.filename = filename;
    }

    public String getFilename() {
        return filename;
    }
}
