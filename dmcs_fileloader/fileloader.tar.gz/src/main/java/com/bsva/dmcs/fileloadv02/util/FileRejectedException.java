package com.bsva.dmcs.fileloadv02.util;

/**
 * TODO Document
 */
public class FileRejectedException extends RuntimeException {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public FileRejectedException(String message) {
        super(message);
    }

}
