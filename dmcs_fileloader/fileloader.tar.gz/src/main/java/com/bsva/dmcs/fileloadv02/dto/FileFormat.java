package com.bsva.dmcs.fileloadv02.dto;

/**
 *
 */
public enum FileFormat {
    VISA, MASTERCARD
}
